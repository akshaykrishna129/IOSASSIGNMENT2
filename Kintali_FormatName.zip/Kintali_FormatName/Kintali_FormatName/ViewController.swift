//
//  ViewController.swift
//  Kintali_FormatName
//
//  Created by Kintali,Akshay Krishna on 1/30/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var detailsHeadingLabel: UILabel!
    @IBOutlet weak var initLabel: UILabel!
    @IBOutlet weak var fNameLabel: UILabel!
    @IBOutlet weak var firstNameTextField: UITextField!
    @IBOutlet weak var fullNameLabel: UILabel!
    @IBOutlet weak var initialsLabel: UILabel!
    @IBOutlet weak var lastNameTextField: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        hideTheLabels()
    }
    
    func hideTheLabels(){
        detailsHeadingLabel.isHidden = true
        fNameLabel.isHidden = true
        initLabel.isHidden = true
    }


    @IBAction func onClickOfSubmit(_ sender: UIButton) {
        detailsHeadingLabel.isHidden = false
        fNameLabel.isHidden = false
        initLabel.isHidden = false
        let firstName = firstNameTextField.text!
        let lastName = lastNameTextField.text!
        fullNameLabel.text = "\(firstName), \(lastName)"
        let firstInitial = firstName.prefix(1)
        let lastInitial = lastName.prefix(1)
        initialsLabel.text = "\(firstInitial)\(lastInitial)"
    }

    
    @IBAction func onClickOfReset(_ sender: UIButton) {
        hideTheLabels()
        firstNameTextField.text = ""
        lastNameTextField.text = ""
        fullNameLabel.text = ""
        initialsLabel.text = ""
        firstNameTextField.becomeFirstResponder()
    }
    
}



